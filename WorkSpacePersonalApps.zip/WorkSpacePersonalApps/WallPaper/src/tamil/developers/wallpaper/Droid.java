package tamil.developers.wallpaper;

import tamil.developers.wallpaper.Speed;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.Typeface;

public class Droid {

	private int x;			// the X coordinate
	private int y;			// the Y coordinate
	private int text_x;
	private int text_y;
	
	private boolean touched;	// if droid is touched/picked up
	private Speed speed;	// the speed with its directions
	
	public Droid(int xy) {
		this.x = 0;
		this.y = 0;
		this.speed = new Speed(xy);
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int get_Text_X() {
		return text_x;
	}
	public void set_Text_X(int Text_x) {
		this.text_x = Text_x;
	}
	public int get_Text_Y() {
		return text_y;
	}
	public void set_Text_Y(int Text_y) {
		this.text_y = Text_y;
	}
	public boolean isTouched() {
		return touched;
	}

	public void setTouched(boolean touched) {
		this.touched = touched;
	}
	
	public Speed getSpeed() {
		return speed;
	}

	public void setSpeed(Speed speed) {
		this.speed = speed;
	}
	public void draw(Canvas canvas,String name, int textColor, 
		int backColor, int fontsize, Typeface tf, boolean shadow) {
		Paint paint = new Paint();
		paint.setColor(get_color(backColor));
		paint.setStyle(Style.FILL);
		canvas.drawPaint(paint);
		paint.setColor(get_color(textColor));
		paint.setTypeface(tf);
		paint.setTextSize(fontsize);
		if (shadow == true){
			if (backColor == 1){
				paint.setShadowLayer((float)1, (float) 2, (float) 2, Color.DKGRAY);
			}else {
				paint.setShadowLayer((float)1, (float) 2, (float) 2, Color.BLACK);
			}
		}
		Rect bounds = new Rect();
		if (name == "" || name == null)
		{
			name = "Tamil Developers";
		}
		paint.getTextBounds(name, 0, name.length(), bounds);
		set_Text_X(bounds.width());
		set_Text_Y(bounds.height());
		canvas.drawText(name, x - (get_Text_X()/2), y - (get_Text_Y()/2), paint);
	}
	public int get_color(int num){
		switch (num) {
		case 1:
			return Color.BLACK;
		case 2:
			return Color.BLUE;
		case 3:
			return Color.CYAN;
		case 4:
			return Color.DKGRAY;
		case 5:
			return Color.GRAY;
		case 6:
			return Color.GREEN;
		case 7:
			return Color.LTGRAY;
		case 8:
			return Color.MAGENTA;
		case 9:
			return Color.RED;
		case 10:
			return Color.WHITE;
		case 11:
			return Color.YELLOW;
		default:
			return Color.WHITE;
		}
	}
	/**
	 * Method which updates the droid's internal state every tick
	 */
	public void update() {
		if (!touched) {
			x += (speed.getXv() * speed.getxDirection()); 
			y += (speed.getYv() * speed.getyDirection());
		}
	}
}
