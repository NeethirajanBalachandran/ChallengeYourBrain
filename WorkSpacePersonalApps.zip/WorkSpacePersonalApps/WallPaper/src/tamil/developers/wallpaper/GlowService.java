package tamil.developers.wallpaper;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

public class GlowService extends WallpaperService {
	 
    @Override
    public Engine onCreateEngine() {
        return new GlowEngine();
    }
 
    private class GlowEngine extends Engine {
        private Droid droid;
        int screen_width;
        int screen_height;
        private boolean mVisible = false;
        private final Handler mHandler = new Handler();
        private final Runnable mUpdateDisplay = new Runnable() {
            public void run() {
                draw();
            }
        };
 
        public GlowEngine() {
            super();
            droid = new Droid(10);
            
        }
 
        private void draw() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                Rect rect = holder.getSurfaceFrame();
                screen_width = rect.width();
                screen_height = rect.height();
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(GlowService.this);
                String maxNumber = prefs.getString("selectname", "Tamil Developers");
                int textColor = Integer.valueOf(prefs.getString("textcolor", "10"));
                int backColor = Integer.valueOf(prefs.getString("backcolor", "1"));
                int fontsize = Integer.valueOf(prefs.getString("fontsize", "16"));
                String font = prefs.getString("font", "STENCIL");
                Typeface tf = Typeface.createFromAsset(getAssets(), "fonts/" + font + ".TTF");
        		boolean shadow = prefs.getBoolean("shadow", false);
        		droid.draw(c,maxNumber, textColor, backColor, fontsize, tf, shadow);
            } finally {
                if (c != null)
                    holder.unlockCanvasAndPost(c);
            }
            mHandler.removeCallbacks(mUpdateDisplay);
            if (mVisible) {
                mHandler.postDelayed(mUpdateDisplay, 200);
            }
            update();
        }
    	public void update() {
    		// check collision with right wall if heading right
    		if (droid.getSpeed().getxDirection() == Speed.DIRECTION_RIGHT
    				&& droid.getX() + droid.get_Text_X() / 2 >= screen_width) {
    			droid.getSpeed().toggleXDirection();
    		}
    		// check collision with left wall if heading left
    		if (droid.getSpeed().getxDirection() == Speed.DIRECTION_LEFT
    				&& droid.getX() - droid.get_Text_X() / 2 <= 0) {
    			droid.getSpeed().toggleXDirection();
    		}
    		// check collision with bottom wall if heading down
    		if (droid.getSpeed().getyDirection() == Speed.DIRECTION_DOWN
    				&& droid.getY() + droid.get_Text_Y() / 2 >= screen_height) {
    			droid.getSpeed().toggleYDirection();
    		}
    		// check collision with top wall if heading up
    		if (droid.getSpeed().getyDirection() == Speed.DIRECTION_UP
    				&& droid.getY() - droid.get_Text_Y() / 2 <= 65) {
    			droid.getSpeed().toggleYDirection();
    		}
    		// Update the lone droid
    		droid.update();
    	}
        @Override
        public void onVisibilityChanged(boolean visible) {
            mVisible = visible;
            if (visible) {
                draw();
            } else {
                mHandler.removeCallbacks(mUpdateDisplay);
            }
        }
 
        @Override
        public void onSurfaceChanged(SurfaceHolder holder,
                    int format, int width, int height) {
            draw();
        }
 
        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            mVisible = false;
            mHandler.removeCallbacks(mUpdateDisplay);
        }
 
        @Override
        public void onDestroy() {
            super.onDestroy();
            mVisible = false;
            mHandler.removeCallbacks(mUpdateDisplay);
        }
    }

}
