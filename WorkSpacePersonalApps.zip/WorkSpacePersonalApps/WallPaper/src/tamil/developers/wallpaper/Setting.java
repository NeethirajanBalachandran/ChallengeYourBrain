package tamil.developers.wallpaper;

import com.startapp.android.publish.StartAppAd;
import com.startapp.android.publish.StartAppSDK;

import android.os.Bundle;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceActivity;
import android.widget.Toast;

public class Setting extends PreferenceActivity {

	private StartAppAd startAppAd = new StartAppAd(this);
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.prefs);

		StartAppSDK.init(this, "107321741", "207683725", true);
		StartAppAd.showSlider(this);
		
		Preference namePreference = getPreferenceScreen().findPreference("selectname");
		namePreference.setOnPreferenceChangeListener(numberCheckListener);
	}
	Preference.OnPreferenceChangeListener numberCheckListener = new OnPreferenceChangeListener() {
	    @Override
	    public boolean onPreferenceChange(Preference preference, Object newValue) {
	      // Check that the string is an integer
	      if (newValue != null && newValue.toString().length() > 0 && newValue.toString().length() < 16) {
	        return true;
	      }
	      // If now create a message to the user
	      if (newValue.toString().length() > 15){
	    	  Toast.makeText(Setting.this, "Maximum length is 15",
	    	          Toast.LENGTH_SHORT).show();
	      }else {
	    	  Toast.makeText(Setting.this, "Invalid Input",
	    			  Toast.LENGTH_SHORT).show();
	      }
	      return false;
	    }
	};
	@Override
	public void onPause() {
		super.onPause();
	    startAppAd.onPause();
	}
	@Override
	public void onResume() {
	    startAppAd.onResume();
		super.onResume();
	}
	@Override
	public void onDestroy() {
		super.onDestroy();
	}
	@Override
	public void onBackPressed() {
		startAppAd.onBackPressed();
		super.onBackPressed();
	}
} 