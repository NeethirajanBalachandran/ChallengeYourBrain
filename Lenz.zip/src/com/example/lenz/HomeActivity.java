package com.example.lenz;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import android.os.Bundle;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class HomeActivity extends ActionBarActivity {

    private String[] mList,mList_brand;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    static SQLiteDatabase myDB1;
	public static final String TABLE_word = "list";
	boolean brand = false;
	int w,h;
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		copy_database_if_need("list.db");
		database_connect();
    	WindowManager win = getWindowManager();
    	Display d = win.getDefaultDisplay();
		w = d.getWidth();
		h = d.getHeight();
		
		set_gridview(1);
		mList = getResources().getStringArray(R.array.navdrwitem);
		mList_brand = getResources().getStringArray(R.array.navdrwitem_1);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);
        set_navigation_drawer(mList);
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
        
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.drawable.device_access_storage, R.string.drawer_open, R.string.drawer_close);
        mDrawerLayout.setDrawerListener(actionBarDrawerToggle);
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	}
	private void copy_database_if_need(String name) {
		File file = new File("/data/data/"+getPackageName() + "/" + name);
		if (!file.exists()){
			try {
				copyDataBase(name);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public void copyDataBase(String name) throws IOException {
		InputStream in =getApplicationContext().getAssets().open(name);
        OutputStream out = new FileOutputStream("/data/data/"+getPackageName() + "/" + name);

        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
    }
	private void set_navigation_drawer(String[] a) {
		final ArrayList<Map<String, String>> list = buildData1(a);
	    String[] from = { "id", "name" };
	    int[] to = {R.id.text1, R.id.text2}; 
	    SimpleAdapter adapter = new SimpleAdapter(this, list,R.layout.nav_drw_item_temp, from, to){
            @Override
	        public View getView(int pos, View convertView, ViewGroup parent){
	            View v = convertView;
	            if(v== null){
	                LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	                v=vi.inflate(R.layout.nav_drw_item_temp, null);
	            }	
	            TextView txt = (TextView)v.findViewById(R.id.text1);
	            txt.setText(list.get(pos).get("id"));
	            txt = (TextView)v.findViewById(R.id.text2);
	            txt.setText(list.get(pos).get("name"));
	            return v;
	        }
		};
		mDrawerList.setAdapter(adapter);
	}
	private class DrawerItemClickListener implements ListView.OnItemClickListener {
	    @Override
	    public void onItemClick(@SuppressWarnings("rawtypes") AdapterView parent, View view, int position, long id) {
	    	selectItem(position);
	    }
	}
	private void selectItem(int position) {
		if (position == 6 && !brand){
			set_navigation_drawer(mList_brand);
			brand = true;
		} else {
			if (brand){
				set_gridview(position + 1);
			} else {
				
			}
			mDrawerLayout.closeDrawer(mDrawerList);
			set_navigation_drawer(mList);
			brand = false;
		}
	}
	private void set_gridview(int cat) {
		GridView gv = (GridView) findViewById(R.id.gridView1);
		final ArrayList<Map<String, String>> list = buildData(cat);
	    String[] from = { "id", "name" };
	    int[] to = {R.id.text1, R.id.text2};
	    SimpleAdapter adapter = new SimpleAdapter(this, list,R.layout.home_list, from, to){
            @Override
	        public View getView(int pos, View convertView, ViewGroup parent){
	            View v = convertView;
	            if(v== null){
	                LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	                v=vi.inflate(R.layout.home_list, null);
	            }
	            String query = "SELECT * FROM " + TABLE_word + " Where id = '" +  list.get(pos).get("id") + "';";
	    		Cursor c = myDB1.rawQuery(query, null);
	            c.moveToFirst();
	            ImageView img = (ImageView)v.findViewById(R.id.main_img);
	            img.setImageResource(drawable(c.getString(c.getColumnIndex("img"))));
	            img.getLayoutParams().width = (w/3);
	            img.getLayoutParams().height = (w/3);
	            c.close();
	            img = (ImageView)v.findViewById(R.id.img1);
	            img.getLayoutParams().width = (w/9);
	            img.getLayoutParams().height = (w/9);
	            final int p = pos;
	            final String id = list.get(pos).get("id");
	            img.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(final View v) {
						myDB1.execSQL("UPDATE " + TABLE_word + " SET wish = 1 where id = '" +  id + "'");
						Toast.makeText(getBaseContext(), "Item "+(p+1) + " added to wish list.", Toast.LENGTH_SHORT).show();
					}
				});
	            img = (ImageView)v.findViewById(R.id.img2);
	            img.getLayoutParams().width = (w/9);
	            img.getLayoutParams().height = (w/9);
	            img.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(final View v) {
						myDB1.execSQL("UPDATE " + TABLE_word + " SET compare = 1 where id = '" +  id + "'");
						Toast.makeText(getBaseContext(), "Item "+(p+1) + " added to compare.", Toast.LENGTH_SHORT).show();
					}
				});
	            img = (ImageView)v.findViewById(R.id.img3);
	            img.getLayoutParams().width = (w/9);
	            img.getLayoutParams().height = (w/9);
	            img.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(final View v) {
						myDB1.execSQL("UPDATE " + TABLE_word + " SET cart = 1 where id = '" +  id + "'");
						Toast.makeText(getBaseContext(), "Item "+(p+1) + " added to cart.", Toast.LENGTH_SHORT).show();
					}
				});
	            TextView txt = (TextView)v.findViewById(R.id.text1);
	            txt.setText(list.get(pos).get("id"));
	            txt = (TextView)v.findViewById(R.id.text2);
	            txt.setText(list.get(pos).get("name"));
	            return v;
	        }
		};
		gv.setAdapter(adapter);
		gv.setOnItemClickListener(new OnItemClickListener() {
	        @Override
	        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
	        	saveFromFile(list.get(position).get("id") +"","select.txt");
				startActivity(new Intent(HomeActivity.this, DetailActivity.class));
	        }
	    });
	}
	protected int drawable(String name) {
		return getResources().getIdentifier(name, "drawable", getPackageName());
	}
	private ArrayList<Map<String, String>> buildData1(String[] a) {    
		ArrayList<Map<String, String>> list = new ArrayList<Map<String, String>>();
	    for (int i = 0; i < a.length; i++){
	    	if (a[i].equals("Brands")) list.add(putData(a[i],"+"));
	    	else list.add(putData(a[i],"-"));
	    }
	    return list;
	}
	private ArrayList<Map<String, String>> buildData(int cat) {
		ArrayList<Map<String, String>> list = new ArrayList<Map<String, String>>();
		String query = "SELECT * FROM " + TABLE_word + " Where cat = " + cat + ";";
		Cursor c = myDB1.rawQuery(query, null);
		saveFromFile(query, "query.txt");
		for (int i = 0; i < c.getCount(); i++){
			c.moveToFirst();
			c.move(i);
			list.add(putData(c.getString(c.getColumnIndex("id")),"Rs: "+c.getInt(1)));
		}
		c.close();
	    return list;
	}
	private HashMap<String, String> putData(String str1, String str2) {
	    HashMap<String, String> item = new HashMap<String, String>();
	    item.put("id", str1);
	    item.put("name", str2);
	    return item;
	}
	@Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        actionBarDrawerToggle.onConfigurationChanged(newConfig);
    }
	@Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        actionBarDrawerToggle.syncState();
    }
	private void saveFromFile(String data, String file_name){
        FileOutputStream fos;
     	try {
    	 	fos = openFileOutput(file_name, Context.MODE_PRIVATE);
    	 	fos.write(data.getBytes());
    	 	fos.close();
     	} catch (IOException e) {	}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
			return true;
        }
	    switch (item.getItemId()) {
	        case R.id.action_search:
	            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
	            return true;
	        case R.id.action_more:
	        	View menuItemView = findViewById(R.id.action_more);
	            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
	            popupMenu.inflate(R.menu.popup_menu);
	            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
	                @Override
	                public boolean onMenuItemClick(MenuItem menuItem) {
	                	switch (menuItem.getItemId()) {
	        	        case R.id.action_cart:
	        	            startActivity(new Intent(getBaseContext(), Cart.class));
	        	            return true;
	        	        case R.id.action_compare:
	        	        	startActivity(new Intent(getBaseContext(), Compare.class));
	        	            return true;
	        	        case R.id.action_wish:
	        	        	startActivity(new Intent(getBaseContext(), WishList.class));
	        	            return true;
	        	        case R.id.action_login:
	        	        	startActivity(new Intent(getBaseContext(), Login.class));
	        	            return true;
	        	        default:
	        	        	return false;
	                	}
	                }
	            });
	            popupMenu.show();
	            return true;
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}
	@SuppressWarnings("deprecation")
	@Override
	public void onBackPressed() {
		AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Exit Alert!");
		alertDialog.setMessage("Do you want to exit this application?");
		alertDialog.setButton("YES", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int which) {
		    		finish();
		        }
		});
		alertDialog.setButton2("NO", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) {
	        }
		});
		alertDialog.show();
	}
}
