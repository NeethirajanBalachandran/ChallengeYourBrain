package com.example.lenz;

import java.util.Locale;

import android.os.Bundle;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class PlaceOrder extends ActionBarActivity {

	static SQLiteDatabase myDB1;
	public static final String TABLE_login = "login";
	public static final String TABLE_order = "order_tb";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_place_order);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

		database_connect();
		
		RadioButton rb = (RadioButton)findViewById(R.id.radio0);
		rb.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				if (arg1){
					set_pass_visible(true);
				} else {
					set_pass_visible(false);
				}
			}
		});
		set_buttons();
	}
	private void set_buttons() {
		Button btn = (Button)findViewById(R.id.btn_continue);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				go_place_order();
			}
		});
	}
	protected void go_place_order() {
		String mail = ((EditText)findViewById(R.id.mail)).getText().toString();
		if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()){
			message("Invalid E-Mail.");
			return;
		}
		if (!((RadioButton)findViewById(R.id.radio1)).isChecked()){
			String pass = ((EditText)findViewById(R.id.et_pass)).getText().toString();
			if (!Validate_Login(mail, pass)){
				message("Invalid Login.");
				return;
			}
		}
		myDB1.execSQL("DROP TABLE IF EXISTS " + TABLE_order);
	    myDB1.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_order + " (id INT(2), mail varchar(50), rupee INT(6), pin INT(10), name varchar(30), address varchar(200), city varchar(30), region varchar(20), phone INT(12));");
	    myDB1.execSQL("INSERT INTO " + TABLE_order + " (id,mail, rupee) VALUES (1,'" + mail + "', 0);");
	    startActivity(new Intent(getBaseContext(), Delivery.class));
	    finish();
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	}
	protected boolean Validate_Login(String mail, String pass) {
		String query = "SELECT * FROM " + TABLE_login + " where mail = '" + mail + "' and pass='" + pass + "';";
		Cursor c = myDB1.rawQuery(query, null);
		int count = c.getCount();
		c.close();
		if (count > 0){
			return true;
		} else {
			return false;
		}
	}
	public void set_pass_visible(boolean vis){
		TextView txt = (TextView)findViewById(R.id.pass);
		if (vis) txt.setVisibility(View.VISIBLE);
		else txt.setVisibility(View.GONE);
		EditText et = (EditText)findViewById(R.id.et_pass);
		if (vis) et.setVisibility(View.VISIBLE);
		else et.setVisibility(View.GONE);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
	@SuppressWarnings("deprecation")
	public void message(String msg) {
		final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Warning");
		alertDialog.setMessage(msg);
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int which) {
		    		alertDialog.cancel();
		        }
		});
		alertDialog.show();
	}
}
