package com.example.lenz;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class Cart extends ActionBarActivity {
	static SQLiteDatabase myDB1;
	public static final String TABLE_word = "list";
	int w,h;
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cart);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		database_connect();
    	WindowManager win = getWindowManager();
    	Display d = win.getDefaultDisplay(); 
		w = d.getWidth(); 
		h = d.getHeight();
		w = (int) (w * 0.90);
		set_gridview();
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	    //myDB1.execSQL("DROP TABLE IF EXISTS " + TABLE_word);
	    //myDB1.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_word + " (id varchar(30),rupee INT(6), img varchar(10), cat INT(2), wish INT(1), cart INT(1), compare INT(1), description varchar(2000));");
	}
	private void set_gridview() {
		GridView gv = (GridView) findViewById(R.id.gridView1);
		final ArrayList<Map<String, String>> list = buildData();
	    String[] from = { "id", "rs" };
	    int[] to = {R.id.text1, R.id.text2}; 
	    SimpleAdapter adapter = new SimpleAdapter(this, list,R.layout.item_list, from, to){
            @Override
	        public View getView(int pos, View convertView, ViewGroup parent){
	            View v = convertView;
	            if(v== null){
	                LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	                v=vi.inflate(R.layout.item_list, null);
	            }
	            final String id = list.get(pos).get("id");
	            String query = "SELECT * FROM " + TABLE_word + " Where id = '" +  id + "';";
	    		Cursor c = myDB1.rawQuery(query, null);
	            c.moveToFirst();
	            ImageView img = (ImageView)v.findViewById(R.id.main_img);
	            img.setImageResource(drawable(c.getString(c.getColumnIndex("img"))));
	            img.getLayoutParams().width = (w/3);
	            img.getLayoutParams().height = (w/3);
	            
	            TextView txt = (TextView)v.findViewById(R.id.text1);
	            txt.setText(list.get(pos).get("id"));
	            txt = (TextView)v.findViewById(R.id.text2);
	            txt.setText(list.get(pos).get("rs"));
	            
	            img = (ImageView)v.findViewById(R.id.remove);
	            img.getLayoutParams().width = (w/9);
	            img.getLayoutParams().height = (w/9);
	            img.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(final View v) {
						myDB1.execSQL("UPDATE " + TABLE_word + " SET cart = 0 where id = '" +  id + "'");
						startActivity(new Intent(getBaseContext(), Cart.class));
						finish();
					}
				});
	            c.close();
	            return v;
	        }
		};
		gv.setAdapter(adapter);
		gv.setClickable(false);
	}
	protected int drawable(String name) {
		return getResources().getIdentifier(name, "drawable", getPackageName());
	}
	private ArrayList<Map<String, String>> buildData() {    
		ArrayList<Map<String, String>> list = new ArrayList<Map<String, String>>();
		String query = "SELECT * FROM " + TABLE_word + " where cart = 1";
		Cursor c = myDB1.rawQuery(query, null);
		if (c.getCount() == 0){
			((TextView)findViewById(R.id.textView1)).setText("There is no item found in Cart.");
		}
		for (int i=0;i<c.getCount();i++){
			c.moveToFirst();
			c.move(i);
			list.add(putData(c.getString(0),"Rs: "+c.getInt(1)));
		}
		c.close();
	    return list;
	}
	private HashMap<String, String> putData(String str1, String str2) {
	    HashMap<String, String> item = new HashMap<String, String>();
	    item.put("id", str1);
	    item.put("rs", str2);
	    return item;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
}
