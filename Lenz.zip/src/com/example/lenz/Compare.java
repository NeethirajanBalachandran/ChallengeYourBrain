package com.example.lenz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class Compare extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_compare);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
}
