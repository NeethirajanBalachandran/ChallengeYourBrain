package com.example.lenz;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Locale;

import android.os.Bundle;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends ActionBarActivity {

	static SQLiteDatabase myDB1;
	public static final String TABLE_login = "login";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		
		database_connect();
		
		TextView txt = (TextView)findViewById(R.id.register_link);
		txt.setLinkTextColor(Color.BLUE);
		txt.setLinksClickable(true);
		txt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(getBaseContext(), Register.class));
				finish();
			}
		});
		
		set_Login();
		set_Cancel();
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	}
	private void set_Cancel() {
		Button btn = (Button)findViewById(R.id.cancel);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(getBaseContext(), HomeActivity.class));
				finish();
			}
		});
	}
	private void set_Login() {
		Button btn = (Button)findViewById(R.id.login);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				if (text(R.id.username).equals("")){
					message("Please enter username/email.");
					return;
				}
				if (text(R.id.password).equals("")){
					message("Please enter password.");
					return;
				}
				if (!Validate_Login(text(R.id.username),text(R.id.password))){
					message("Invalid Login.");
					return;
				}
				message("Login Successful.");
				saveFromFile(text(R.id.username), "login_mail.txt");
				startActivity(new Intent(getBaseContext(), HomeActivity.class));
				finish();
			}
		});
	}
	protected boolean Validate_Login(String mail, String pass) {
		String query = "SELECT * FROM " + TABLE_login + " where mail = '" + mail + "' and pass='" + pass + "';";
		Cursor c = myDB1.rawQuery(query, null);
		int count = c.getCount();
		c.close();
		if (count > 0){
			return true;
		} else {
			return false;
		}
	}
	public String text(int id){
		EditText et = (EditText)findViewById(id);
		return et.getText().toString();
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
	@SuppressWarnings("deprecation")
	public void message(String msg) {
		final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Warning");
		alertDialog.setMessage(msg);
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int which) {
		    		alertDialog.cancel();
		        }
		});
		alertDialog.show();
	}
	@SuppressWarnings("unused")
	private String loadFromFile(String file_name){
        String line=null;
        String res = null;
        try {
              InputStream in = openFileInput(file_name);
              if (in != null) {
                    InputStreamReader input = new InputStreamReader(in);
                    BufferedReader buffreader = new BufferedReader(input);
                    res = "";   
                    while (( line = buffreader.readLine()) != null) {
                          res += line;
                    }
                    in.close();
              }
        } catch(Exception e){
             //Toast.makeText(getApplicationContext(),e.toString() +   e.getMessage(),Toast.LENGTH_SHORT).show();
        }
		return res;
	}
	private void saveFromFile(String data, String file_name){
        
        FileOutputStream fos = null;
        try {
        	 fos = openFileOutput(file_name, Context.MODE_PRIVATE);
        	 fos.write(data.getBytes());
        	 fos.close();
		} catch (IOException e) {
        }
	}
}
