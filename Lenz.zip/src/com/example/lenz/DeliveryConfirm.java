package com.example.lenz;

import java.util.Locale;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DeliveryConfirm extends ActionBarActivity {

	static SQLiteDatabase myDB1;
	public static final String TABLE_login = "login";
	public static final String TABLE_order = "order_tb";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_delivery_confirm);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		database_connect();
		show_details();
		set_buttons();
	}
	private void set_buttons() {
		Button btn = (Button)findViewById(R.id.confirm);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(getBaseContext(), Delivery.class));
				finish();
			}
		});
		btn = (Button)findViewById(R.id.btn_continue);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(getBaseContext(), Pay.class));
				finish();
			}
		});
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	}
	private void show_details() {
		String query = "SELECT * FROM " + TABLE_order + " where id = 1";
		Cursor c = myDB1.rawQuery(query, null);
		if (c.getCount() > 0){
			c.moveToFirst();
			set_address(R.id.address1, c.getString(c.getColumnIndex("name")));
			set_address(R.id.address2, c.getString(c.getColumnIndex("address")));
			set_address(R.id.address3, c.getString(c.getColumnIndex("city")) + " - " + c.getString(c.getColumnIndex("pin")) );
			set_address(R.id.address4, c.getString(c.getColumnIndex("region")));
			set_address(R.id.address5, "Ph: "+ c.getString(c.getColumnIndex("phone")));

			set_address(R.id.amount, c.getString(c.getColumnIndex("rupee")) + ".00");
		}
		c.close();
	}
	private void set_address(int id, String string) {
		TextView txt = (TextView)findViewById(id);
		txt.setText(string);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
}
