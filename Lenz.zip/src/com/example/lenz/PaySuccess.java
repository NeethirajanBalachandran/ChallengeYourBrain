package com.example.lenz;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PaySuccess extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pay_success);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		
		TextView txt = (TextView)findViewById(R.id.track_id);
		txt.setText("Your order # "+ loadFromFile("pay_id.txt"));
		
		Button btn = (Button)findViewById(R.id.go_button);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(getBaseContext(), HomeActivity.class));
				finish();
			}
		});
		
	}
	private String loadFromFile(String file_name){
        String line=null;
        String res = null;
        try {
              InputStream in = openFileInput(file_name);
              if (in != null) {
                    InputStreamReader input = new InputStreamReader(in);
                    BufferedReader buffreader = new BufferedReader(input);
                    res = "";   
                    while (( line = buffreader.readLine()) != null) {
                          res += line;
                    }
                    in.close();
              }else{
              }
        } catch(Exception e){
        }
		return res;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
}
