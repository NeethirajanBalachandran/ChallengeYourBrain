package com.example.lenz;

import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.WindowManager;
import android.widget.ImageView;
import android.app.Activity;
import android.content.Intent;

public class MainActivity extends Activity {
	
	Handler handler;
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		int Measuredwidth = 0;
    	WindowManager win = getWindowManager();
    	Display d = win.getDefaultDisplay(); 
		Measuredwidth = d.getWidth();
		
		ImageView img = (ImageView)findViewById(R.id.imageView1);
		img.getLayoutParams().width = Measuredwidth / 2;
		img.getLayoutParams().height = Measuredwidth / 2;
		Start();
	}
	private void Start() {
		handler = new Handler();
	    startProgress();		
	}
	public void startProgress() {
	    // Do something long
	    Runnable runnable = new Runnable() {
	      @Override
	      public void run() {
	        for (int i = 0; i <= 100; i++) {
	          //final int value = i;
	          try {
	            Thread.sleep(15);
	          } catch (InterruptedException e) {
	            e.printStackTrace();
	          }
	          handler.post(new Runnable() {
	            @Override
	            public void run() {
	              
	            }
	          });
	        }
	        startActivity(new Intent(MainActivity.this, DeliveryConfirm.class));
	        finish();
	      }
	    };
	    new Thread(runnable).start();
	}
    @Override
    public void onBackPressed(){
    }
}
