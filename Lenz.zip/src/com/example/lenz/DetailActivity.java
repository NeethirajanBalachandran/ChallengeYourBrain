package com.example.lenz;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Locale;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends ActionBarActivity {

	static SQLiteDatabase myDB1;
	public static final String TABLE_word = "list";
	int w,h;
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detail);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
    	WindowManager win = getWindowManager();
    	Display d = win.getDefaultDisplay(); 
		w = d.getWidth(); 
		w = (int) (w * 0.90);
		database_connect();

		String query = "SELECT * FROM " + TABLE_word + " where id = '" + loadFromFile("select.txt") + "';";
		Cursor c = myDB1.rawQuery(query, null);
		c.moveToFirst();
		ImageView img = (ImageView)findViewById(R.id.img_main);
		img.setImageResource(drawable(c.getString(c.getColumnIndex("img"))));
		img.getLayoutParams().width = w;
		img.getLayoutParams().height = w;
		img.setPadding(2, 2, 2, 2);
		
		img = (ImageView)findViewById(R.id.img1);
		img.getLayoutParams().width = w/3;
		img.getLayoutParams().height = w/3;
		img.setPadding(2, 2, 2, 2);
		if (drawable(c.getString(c.getColumnIndex("img")) + "_1") == 0){
			img.setVisibility(View.GONE);
		} else {
			img.setImageResource(drawable(c.getString(c.getColumnIndex("img")) + "_1"));
		}
		img = (ImageView)findViewById(R.id.img2);
		img.getLayoutParams().width = w/3;
		img.getLayoutParams().height = w/3;
		img.setPadding(2, 2, 2, 2);
		if (drawable(c.getString(c.getColumnIndex("img")) + "_2") == 0){
			img.setVisibility(View.GONE);
		} else {
			img.setImageResource(drawable(c.getString(c.getColumnIndex("img")) + "_2"));
		}
		img = (ImageView)findViewById(R.id.img3);
		img.getLayoutParams().width = w/3;
		img.getLayoutParams().height = w/3;
		img.setPadding(2, 2, 2, 2);
		if (drawable(c.getString(c.getColumnIndex("img")) + "_3") == 0){
			img.setVisibility(View.GONE);
		} else {
			img.setImageResource(drawable(c.getString(c.getColumnIndex("img")) + "_3"));
		}
		Button btn = (Button)findViewById(R.id.button1);
		btn.setText("Price: Rs. " + c.getInt(c.getColumnIndex("rupee")));
		
		btn = (Button)findViewById(R.id.instack);
		btn.setText("In Stack");
		
		TextView text = (TextView)findViewById(R.id.description);
		text.setText(c.getString(c.getColumnIndex("description")));
		text = (TextView)findViewById(R.id.headtitle);
		text.setText(c.getString(c.getColumnIndex("id")));
		c.close();
		set_buttons();
	}
	private void set_buttons() {
		btn(R.id.buy);
		btn(R.id.cart);
		btn(R.id.share);
	}
	public void btn(final int id){
		Button btn = (Button)findViewById(id);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (id) {
				case R.id.buy:
					startActivity(new Intent(getBaseContext(), PlaceOrder.class));
					finish();
					break;
				case R.id.cart:
					
					break;
				case R.id.share:
					
					break;

				default:
					break;
				}
			}
		});
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	}
	protected int drawable(String name) {
		return getResources().getIdentifier(name, "drawable", getPackageName());
	}
	private String loadFromFile(String file_name){
        String line=null;
        String res = null;
        try {
              InputStream in = openFileInput(file_name);
              if (in != null) {
                    InputStreamReader input = new InputStreamReader(in);
                    BufferedReader buffreader = new BufferedReader(input);
                    res = "";   
                    while (( line = buffreader.readLine()) != null) {
                          res += line;
                    }
                    in.close();
              }else{
              }
        } catch(Exception e){
        }
		return res;
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
}
