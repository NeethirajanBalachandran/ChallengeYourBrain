package com.example.lenz;

import java.util.Locale;

import android.os.Bundle;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class Register extends ActionBarActivity {
	boolean valid = false;
	boolean agree = false;
	static SQLiteDatabase myDB1;
	public static final String TABLE_login = "login";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		
		database_connect();
		
		Spinner dropdown = (Spinner)findViewById(R.id.country);
		String[] items = new String[]{"India"};
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items);
		dropdown.setAdapter(adapter);
		dropdown.setSelection(0);
		
		Spinner dropdown1 = (Spinner)findViewById(R.id.region);
		String[] items1 = getResources().getStringArray(R.array.state_list);
		ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items1);
		dropdown1.setAdapter(adapter1);
		dropdown1.setSelection(0);
		
		set_submit();
		set_cancel();
		set_agree_checkbox();
		
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	    myDB1.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_login + " (mail nvarchar(50), phone INT(12), fName varchar(50), lName varchar(50), address nvarchar(500), city varchar(50), pin varchar(10), country varchar(30), region varchar(30), pass nvarchar(20), newsletter INT(1));");
	}
	private void set_agree_checkbox() {
		CheckBox ch = (CheckBox)findViewById(R.id.agree);
		ch.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				if (arg1){
					message_cp("content policy!!!");
				}
			}
		});
	}
	private void set_cancel() {
		Button btn = (Button)findViewById(R.id.cancel);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(getBaseContext(), Login.class));
				finish();
			}
		});
	}
	private void set_submit() {
		Button btn = (Button)findViewById(R.id.submit);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				validate();
				if (valid){
					int news = 0;
					if (((RadioButton)findViewById(R.id.radioYes)).isChecked()){
						news = 1;
					}
					save_registration_data(text(R.id.et_firstname),text(R.id.et_lastname),
							text(R.id.et_mail), text(R.id.et_phone), text(R.id.et_address), 
							text(R.id.et_city), text(R.id.et_pincode),"India","", 
							text(R.id.et_pass), news);
					message_success("Your registration done successfully. You can login now.");
				}
			}
		});
	}
	public String text(int id){
		EditText et = (EditText)findViewById(id);
		return et.getText().toString();
	}
	public void save_registration_data(String fName, String lName, String mail, String ph, String address, String city, String pin, String country, String region, String pass, int newsletter){
		String query = "INSERT into " + TABLE_login + " (mail, phone, fName, lName, address, city, pin, country, region, pass, newsletter) " + " Values " + "('" + mail + "','" + ph + "','" + fName + "','" + lName + "','" + address + "','" + city + "','" + pin + "','" + country + "','" + region + "','" + pass + "'," + newsletter +");";
		myDB1.execSQL(query);
	}
	protected void validate() {
		EditText edit =  (EditText) findViewById(R.id.et_firstname);
		if (edit.getText().toString().equals("")){
			message("Please enter FirstName.");
			edit.setSelected(true);
			return;
		}
		
		edit =  (EditText) findViewById(R.id.et_lastname);
		if (edit.getText().toString().equals("")){
			message("Please enter LastName.");
			edit.setSelected(true);
			return;
		}
		
		edit =  (EditText) findViewById(R.id.et_mail);
		if (edit.getText().toString().equals("")){
			message("Please enter E-mail.");
			edit.setPressed(true);
			return;
		}
		if (!Patterns.EMAIL_ADDRESS.matcher(edit.getText().toString()).matches()){
			message("Invalid E-Mail.");
			edit.setFocusable(true);
			return;
		}
		if(check_email_address_exist(edit.getText().toString())){
			message("E-mail address already exist. Please use another e-mail");
			edit.setFocusable(true);
			return;
		}
		
		edit =  (EditText) findViewById(R.id.et_phone);
		if (edit.getText().toString().equals("")){
			message("Please enter mobile number.");
			edit.setFocusable(true);
			return;
		}
		if (edit.getText().toString().length() != 10){
			message("Invalid mobile number. Enter 10 digit of your mobile number.");
			edit.setFocusable(true);
			return;
		}
		
		edit =  (EditText) findViewById(R.id.et_address);
		if (edit.getText().toString().equals("")){
			message("Please enter your address.");
			edit.setFocusable(true);
			return;
		}
		
		edit =  (EditText) findViewById(R.id.et_city);
		if (edit.getText().toString().equals("")){
			message("Please enter your City.");
			edit.setFocusable(true);
			return;
		}
		
		edit =  (EditText) findViewById(R.id.et_pincode);
		if (edit.getText().toString().equals("")){
			message("Please enter your pin code.");
			edit.setFocusable(true);
			return;
		}
		
		edit =  (EditText) findViewById(R.id.et_pass);
		if (edit.getText().toString().equals("")){
			message("Please enter password");
			edit.setFocusable(true);
			return;
		}
		String pass = edit.getText().toString();
		edit =  (EditText) findViewById(R.id.et_pass_con);
		if (edit.getText().toString().equals("")){
			message("Please enter confirm password");
			edit.setFocusable(true);
			return;
		}
		String pass1 = edit.getText().toString();
		if (!pass.equals(pass1)){
			message("Password doesn't match.");
			edit.setFocusable(true);
			return;
		}
		CheckBox ch = (CheckBox)findViewById(R.id.agree);
    	if (!ch.isChecked()){
    		message("Please read the content policy and click ok.");
			return;
    	}
    	valid = true;
	}
	private boolean check_email_address_exist(String mail) {
		String query = "SELECT * FROM " + TABLE_login + " where mail = '" + mail + "';";
		Cursor c = myDB1.rawQuery(query, null);
		int count = c.getCount();
		c.close();
		if (count > 0){
			return true;
		} else {
			return false;
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
	@SuppressWarnings("deprecation")
	public void message(String msg) {
		final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Warning");
		alertDialog.setMessage(msg);
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int which) {
		    		alertDialog.cancel();
		        }
		});
		alertDialog.show();
	}
	@SuppressWarnings("deprecation")
	public void message_success(String msg) {
		final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Success");
		alertDialog.setMessage(msg);
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int which) {
		    		startActivity(new Intent(getBaseContext(), Login.class));
		    		finish();
		        }
		});
		alertDialog.show();
	}
	@SuppressWarnings("deprecation")
	public void message_cp(String msg) {
		final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Policy Content.");
		alertDialog.setMessage(msg);
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) {
	        	CheckBox ch = (CheckBox)findViewById(R.id.agree);
	        	ch.setChecked(true);
	        }
		});
		alertDialog.setButton2("CANCEL", new DialogInterface.OnClickListener() {
	        public void onClick(DialogInterface dialog, int which) {
	        	CheckBox ch = (CheckBox)findViewById(R.id.agree);
	        	ch.setChecked(false);
	        }
		});
		alertDialog.show();
	}
}

