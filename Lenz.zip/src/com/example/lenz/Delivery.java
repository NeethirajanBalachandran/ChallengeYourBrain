package com.example.lenz;

import java.util.Locale;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.PopupMenu.OnMenuItemClickListener;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Delivery extends ActionBarActivity {

	static SQLiteDatabase myDB1;
	public static final String TABLE_login = "login";
	public static final String TABLE_order = "order_tb";
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_delivery);
		
		ActionBar actionBar = getSupportActionBar();
		actionBar.show();
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowTitleEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		
		database_connect();
		
		Spinner dropdown1 = (Spinner)findViewById(R.id.region);
		String[] items1 = getResources().getStringArray(R.array.state_list);
		ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items1);
		dropdown1.setAdapter(adapter1);
		dropdown1.setSelection(0);
		set_buttons();
		check_data();
	}
	private void check_data() {
		String query = "SELECT * FROM " + TABLE_order + " where id = 1";
		Cursor c = myDB1.rawQuery(query, null);
		if (c.getCount() > 0){
			c.moveToFirst();
			if (c.getString(c.getColumnIndex("pin")) != "") 	set_address(R.id.d_et_pin, c.getString(c.getColumnIndex("pin")));
			if (c.getString(c.getColumnIndex("name")) != "") 	set_address(R.id.d_et_name, c.getString(c.getColumnIndex("name")));
			if (c.getString(c.getColumnIndex("address")) != "")	set_address(R.id.d_et_address, c.getString(c.getColumnIndex("address")));
			if (c.getString(c.getColumnIndex("city")) != "") 	set_address(R.id.d_et_city, c.getString(c.getColumnIndex("city")));
			if (c.getString(c.getColumnIndex("phone")) != "") 	set_address(R.id.d_et_phone, c.getString(c.getColumnIndex("phone")));
		}
		c.close();
	}
	private void set_address(int id, String string) {
		EditText et = (EditText)findViewById(id);
		et.setText(string);
	}
	private void set_buttons() {
		Button btn = (Button)findViewById(R.id.btn_continue);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				go_place_delivery();
			}
		});
	}
	protected void go_place_delivery() {
		if (!validate()){
			return;
		}
		myDB1.execSQL("UPDATE " + TABLE_order + " SET pin = " + ((EditText)findViewById(R.id.d_et_pin)).getText() + " where id = 1");
		myDB1.execSQL("UPDATE " + TABLE_order + " SET name = '" + ((EditText)findViewById(R.id.d_et_name)).getText() + "' where id = 1");
		myDB1.execSQL("UPDATE " + TABLE_order + " SET address = '" + ((EditText)findViewById(R.id.d_et_address)).getText() + "' where id = 1");
		myDB1.execSQL("UPDATE " + TABLE_order + " SET city = '" + ((EditText)findViewById(R.id.d_et_city)).getText() + "' where id = 1");
		myDB1.execSQL("UPDATE " + TABLE_order + " SET region = '" + "TamilNadu" + "' where id = 1");
		myDB1.execSQL("UPDATE " + TABLE_order + " SET phone = " + ((EditText)findViewById(R.id.d_et_phone)).getText() + " where id = 1");
		startActivity(new Intent(getBaseContext(), DeliveryConfirm.class));
		finish();
	}
	private boolean validate() {
		EditText edit =  (EditText) findViewById(R.id.d_et_pin);
		if (edit.getText().toString().equals("")){
			message("Please enter Pin code.");
			return false;
		}
		edit =  (EditText) findViewById(R.id.d_et_name);
		if (edit.getText().toString().equals("")){
			message("Please enter your name.");
			return false;
		}
		edit =  (EditText) findViewById(R.id.d_et_address);
		if (edit.getText().toString().equals("")){
			message("Please enter Address.");
			return false;
		}
		edit =  (EditText) findViewById(R.id.d_et_city);
		if (edit.getText().toString().equals("")){
			message("Please enter City.");
			return false;
		}
		edit =  (EditText) findViewById(R.id.d_et_phone);
		if (edit.getText().toString().equals("")){
			message("Please enter phone number.");
			return false;
		}
		if (edit.getText().toString().length() != 10){
			message("Invalid phone number. Please enter the 10 digit number.");
			return false;
		}
		return true;
	}
	private void database_connect() {
		String dbname1  = "/data/data/"+getPackageName()+"/list.db";
	    myDB1 = openOrCreateDatabase(dbname1 , Context.MODE_PRIVATE, null);
	    myDB1.setVersion(1);
	    myDB1.setLocale(Locale.getDefault());
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.top_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case R.id.action_search:
            Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
            return true;
        case R.id.action_more:
        	View menuItemView = findViewById(R.id.action_more);
            PopupMenu popupMenu = new PopupMenu(this, menuItemView);
            popupMenu.inflate(R.menu.popup_menu);
            popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                	switch (menuItem.getItemId()) {
        	        case R.id.action_cart:
        	            startActivity(new Intent(getBaseContext(), Cart.class));
        	            return true;
        	        case R.id.action_compare:
        	        	startActivity(new Intent(getBaseContext(), Compare.class));
        	            return true;
        	        case R.id.action_wish:
        	        	startActivity(new Intent(getBaseContext(), WishList.class));
        	            return true;
        	        case R.id.action_login:
        	        	startActivity(new Intent(getBaseContext(), Login.class));
        	            return true;
        	        default:
        	        	return false;
                	}
                }
            });
            popupMenu.show();
            return true;
        default:
            return super.onOptionsItemSelected(item);
		}
	}
	@SuppressWarnings("deprecation")
	public void message(String msg) {
		final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setTitle("Warning");
		alertDialog.setMessage(msg);
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int which) {
		    		alertDialog.cancel();
		        }
		});
		alertDialog.show();
	}
}
